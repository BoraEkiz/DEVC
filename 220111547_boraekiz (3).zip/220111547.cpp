#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
FILE *dosya,*yedek; // foknsiyonlarda dosya islemleri yap�laca��ndan global tan�mlad�m
struct ogrenci{
 char ad[10];
 int no, Not;
 };
struct ogrenci kisi;
void kayitGirisi(void); 
void kayitListele(void);
void kayitSilme(void);

int main(){

do{ 
system("cls");
printf("\t\t--------------E-OKUL OGRENCI KAYIT SISTEMI-------------- \n1- Kayit Girisi\n2- Kayit Listeleme \n3- Kayit Silme \n4- Cikis \n\nLutfen islemi seciniz:");
switch(getch()){
 case '1':{ // Kayit Giri�i
 system("cls");
 kayitGirisi();
  break;
 }
 case '2':{ // Kayit Listeleme
 system("cls");
 kayitListele();
  break;
 }
 case '3':{ // Kayit Silme
 system("cls");
 kayitSilme();
  break;
 }
 
 case '6':{ // Cikis
    return 0;
  break;
 }
 default:{
  printf("Hatali Giris");
 }
}
}while(1);
 getch();
 return 0;
}

void kayitGirisi(void){
 int i=0;
 dosya=fopen("sinif.txt","a+"); // w ile yazd�rma islemi yap�yoruz.
 if(dosya == NULL){
  puts("Dosya acilamadi.");
  exit(1);}
 puts("\nOgrenci bilgilerini girin: ");
 do{ // �nce bellege yazd�r�yoruz.
  i++;
  fflush(stdin);
  printf("%d. Ogrencinin Adi : ",i);
  gets(kisi.ad);
  printf("%d. Ogrencinin Numarasi : ",i);
  scanf("%d",&kisi.no);
  printf("%d. Ogrencinin Notu : ",i);
  scanf("%d",&kisi.Not);
  printf("\n");
  // Sonra dosyaya yazd�r�yoruz.
  fprintf(dosya,"%s %d %d\n",kisi.ad,kisi.no,kisi.Not);
  puts("Yeni bir kayit icin bir tusa, cikmak icin ESC tusuna basiniz.");
 }while(getch()!=27);
 fclose(dosya);
 puts("\nBilgiler kaydedildi devam etmek icin bir tusa basin ...");
 getch();
}

void kayitListele(void){
 dosya = fopen("sinif.txt","r"); // r ile okuma islemi yap�yoruz.
 if(dosya == NULL){
  puts("Dosya acilamadi.");
  exit(1);
 }
 while(!feof(dosya)){ // !feof dosyan�n sonuna geldi�inde d�ng�den ��kmak i�in
  fflush(stdout);
  fscanf(dosya,"%s %d %d\n",kisi.ad,&kisi.no,&kisi.Not); // �nceden dosyaya yazd�rd�klar�m�z� �imdi belle�e yazd�r�yoruz
   if(kisi.ad != NULL){ // Yukar�da isim okunabilmi� ise ekrana yazd�rmak i�in
    printf("\n%s %d %d",kisi.ad,kisi.no,kisi.Not);
   }
 }
 fclose(dosya);
 puts("\nBilgiler listelendi devam etmek icin bir tusa basin ...");
 getch();
}

void kayitSilme(void){
 int numara,durum=0;// durum 1 oldu�unda kayit silinmis demektir
 printf("\nSilinecek ogrencinin numarasini giriniz : ");
 scanf("%d",&numara);
 dosya = fopen("sinif.txt","r");// sinif dosyas�ndan sadece okuma yapilacak bu y�zden r kullan�yoruz.
 yedek = fopen("yedek.txt","w");// yedek dosyas�na yazma islemi yapaca��z.
 if(dosya == NULL){
  puts("Dosya acilamadi");
  exit(1);
 }
 while(!feof(dosya)){
  fscanf(dosya,"%s %d %d\n",kisi.ad,&kisi.no,&kisi.Not); // dosyay� okuyoruz ve degerleri belle�e yaz�yoruz
    if(numara != kisi.no){ // E�er girilen numara dosyada okunan de�ere e�it de�ilse if d�ng�s�ne girer.
     fprintf(yedek,"%s %d %d\n",kisi.ad,kisi.no,kisi.Not);
     /* Okunan de�er yedek dosyas�na yaz�l�r*/
    }
    else durum=1; // Numara okunan de�ere e�itse , okunan o de�er yedek dosyas�na yaz�lmaz b�ylece o de�er silinmi� olur
 }
 fclose(dosya);
 fclose(yedek);
 if(durum == 1){// durum=1 ise okunan de�er silinmi� demektir o halde sinif.txt dosyas�n� sileriz yedek.txt ad�n� sinif.txt olarak de�i�tiririz
  remove("sinif.txt"); //silmek icin
  rename("yedek.txt","sinif.txt"); // isim de�i�ikli�i i�in
  puts("Silme islemi tamamlandi devam etmek icin bir tusa basin");
 } 
 else{ // durum=1 de�ilse okunan de�er silinmemi�tir, daha do�rusu girilen numara dosyada bulunmamaktad�r
  remove("yedek.txt"); // yedek dosyas�n� kullanamad�g�m�zdan siliyoruz
  printf(" %d numarasinda bir ogrenci bulunamadi devam etmek icin bir tusa basin ...",numara);
 }
 fflush(stdin);
 getch();
}

